document.addEventListener('DOMContentLoaded', () => {
  const toggleMain = document.getElementById('toggleMain');
  const statusBadge = document.getElementById('statusBadge');
  const bannerCount = document.getElementById('bannerCount');
  const videoCount = document.getElementById('videoCount');
  const lastUpdateText = document.getElementById('lastUpdateText');
  const btnSync = document.getElementById('btnSync');

  chrome.storage.local.get(['superprokicked_enabled', 'superprokicked_stats', 'superprokicked_last_update'], (res) => {
    const isEnabled = res.superprokicked_enabled ?? true;
    const stats = res.superprokicked_stats || { blockedCount: 0, videoAdsBypassed: 0 };
    const lastUpdate = res.superprokicked_last_update;

    toggleMain.checked = isEnabled;
    bannerCount.textContent = stats.blockedCount;
    videoCount.textContent = stats.videoAdsBypassed;
    if (lastUpdate) {
      lastUpdateText.textContent = `Son Güncelleme: ${lastUpdate}`;
    }
    updateUI(isEnabled);
  });

  toggleMain.addEventListener('change', () => {
    const newState = toggleMain.checked;
    chrome.storage.local.set({ superprokicked_enabled: newState }, () => {
      updateUI(newState);
    });
  });

  btnSync.addEventListener('click', () => {
    btnSync.textContent = "Kontrol Ediliyor...";
    chrome.runtime.sendMessage({ type: 'FORCE_UPDATE_RULES' }, (response) => {
      chrome.storage.local.get(['superprokicked_last_update'], (res) => {
        if (res.superprokicked_last_update) {
          lastUpdateText.textContent = `Son Güncelleme: ${res.superprokicked_last_update}`;
        }
        btnSync.textContent = "Tamamlandı!";
        setTimeout(() => { btnSync.textContent = "Şimdi Güncelle"; }, 2000);
      });
    });
  });

  function updateUI(isEnabled) {
    if (isEnabled) {
      statusBadge.textContent = "Aktif";
      statusBadge.className = "status-badge";
    } else {
      statusBadge.textContent = "Devre Dışı";
      statusBadge.className = "status-badge disabled";
    }
  }
});