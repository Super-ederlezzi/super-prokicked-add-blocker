export const STORAGE_KEYS = {
  ENABLED: 'superprokicked_enabled',
  STATS: 'superprokicked_stats',
  DYNAMIC_RULES: 'superprokicked_dynamic_rules',
  LAST_UPDATE: 'superprokicked_last_update'
};

export const DEFAULT_SETTINGS = {
  [STORAGE_KEYS.ENABLED]: true,
  [STORAGE_KEYS.STATS]: { blockedCount: 0, videoAdsBypassed: 0 },
  [STORAGE_KEYS.DYNAMIC_RULES]: [
    '[class*="ad-box"]',
    '[class*="sponsor-"]',
    '[id*="ad-banner"]',
    '.kick-ad-container',
    'a[href*="doubleclick.net"]'
  ],
  [STORAGE_KEYS.LAST_UPDATE]: null
};

export const REMOTE_RULES_URL = "https://raw.githubusercontent.com/superprokicked/rules/main/rules.json";
