(function() {
  let isEnabled = true;
  let activeSelectors = [
    '[class*="ad-box"]',
    '[class*="sponsor-"]',
    '[id*="ad-banner"]',
    '.kick-ad-container',
    'a[href*="doubleclick.net"]'
  ];

  chrome.storage.local.get(['superprokicked_enabled', 'superprokicked_dynamic_rules'], (res) => {
    isEnabled = res.superprokicked_enabled ?? true;
    if (res.superprokicked_dynamic_rules && Array.isArray(res.superprokicked_dynamic_rules)) {
      activeSelectors = res.superprokicked_dynamic_rules;
    }
    if (isEnabled) initAdBlockEngine();
  });

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.superprokicked_enabled) {
      isEnabled = changes.superprokicked_enabled.newValue;
    }
    if (changes.superprokicked_dynamic_rules) {
      activeSelectors = changes.superprokicked_dynamic_rules.newValue;
    }
  });

  function initAdBlockEngine() {
    const removeAds = () => {
      if (!isEnabled) return;
      activeSelectors.forEach(selector => {
        document.querySelectorAll(selector).forEach(el => {
          el.remove();
          chrome.runtime.sendMessage({ type: 'INCREMENT_STATS', category: 'banner' });
        });
      });
    };

    const handleVideoAds = () => {
      if (!isEnabled) return;
      const video = document.querySelector('video');
      const adNotice = document.querySelector('.stream-ad-overlay, [class*="adNotice"], [class*="ad-overlay"]');

      if (video) {
        if (adNotice) {
          if (!video.dataset.superprokickedBypassing) {
            video.dataset.superprokickedBypassing = "true";
            video.muted = true;
            video.playbackRate = 16.0;
            chrome.runtime.sendMessage({ type: 'INCREMENT_STATS', category: 'video' });
          }
        } else if (video.dataset.superprokickedBypassing) {
          delete video.dataset.superprokickedBypassing;
          video.muted = false;
          video.playbackRate = 1.0;
        }
      }
    };

    const observer = new MutationObserver(() => {
      removeAds();
      handleVideoAds();
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }
})();