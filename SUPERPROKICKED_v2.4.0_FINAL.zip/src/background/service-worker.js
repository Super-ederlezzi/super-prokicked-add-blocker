import { STORAGE_KEYS, DEFAULT_SETTINGS, REMOTE_RULES_URL } from '../shared/constants.js';

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get([STORAGE_KEYS.ENABLED], (res) => {
    if (res[STORAGE_KEYS.ENABLED] === undefined) {
      chrome.storage.local.set(DEFAULT_SETTINGS);
    }
  });
  chrome.alarms.create('checkRemoteRules', { periodInMinutes: 1440 });
  fetchAndStoreRemoteRules();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkRemoteRules') {
    fetchAndStoreRemoteRules();
  }
});

async function fetchAndStoreRemoteRules() {
  try {
    const response = await fetch(REMOTE_RULES_URL);
    if (response.ok) {
      const data = await response.json();
      if (data && Array.isArray(data.selectors)) {
        chrome.storage.local.set({
          [STORAGE_KEYS.DYNAMIC_RULES]: data.selectors,
          [STORAGE_KEYS.LAST_UPDATE]: new Date().toLocaleString('tr-TR')
        });
      }
    }
  } catch (err) {
    console.log('Canlı kural kontrolü.');
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'INCREMENT_STATS') {
    chrome.storage.local.get([STORAGE_KEYS.STATS], (res) => {
      const currentStats = res[STORAGE_KEYS.STATS] || { blockedCount: 0, videoAdsBypassed: 0 };
      if (message.category === 'banner') currentStats.blockedCount++;
      if (message.category === 'video') currentStats.videoAdsBypassed++;
      
      chrome.storage.local.set({ [STORAGE_KEYS.STATS]: currentStats });
    });
  }
  if (message.type === 'FORCE_UPDATE_RULES') {
    fetchAndStoreRemoteRules().then(() => {
      sendResponse({ status: 'done' });
    });
    return true;
  }
});